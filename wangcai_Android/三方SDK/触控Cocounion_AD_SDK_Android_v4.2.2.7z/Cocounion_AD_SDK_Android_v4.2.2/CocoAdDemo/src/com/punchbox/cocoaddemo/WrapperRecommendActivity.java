package com.punchbox.cocoaddemo;

import android.os.Bundle;
import android.widget.Toast;

import com.punchbox.exception.PBException;
import com.punchbox.listener.AdListener;
import com.punchbox.recommend.RecommendActivity;

public class WrapperRecommendActivity extends RecommendActivity implements AdListener {
	@Override
    protected void onCreate(Bundle savedInstanceState) {
	    // TODO Auto-generated method stub
	    super.onCreate(savedInstanceState);
    }

	@Override
    protected void onDestroy() {
	    super.onDestroy();
    }

	@Override
    public void setAdListener(AdListener listener) {
	    super.setAdListener(listener);
    }

	@Override
    public void onReceiveAd() {
	    super.onReceiveAd();
	    Toast.makeText(getApplicationContext(), "onReceiveAd rec", Toast.LENGTH_SHORT).show();
    }

	@Override
    public void onFailedToReceiveAd(PBException ex) {
	    super.onFailedToReceiveAd(ex);
	    Toast.makeText(getApplicationContext(), "onFailedToReceiveAd rec:" + ex.getErrorCode(), Toast.LENGTH_SHORT).show();
    }

	@Override
    public void onPresentScreen() {
	    // TODO Auto-generated method stub
	    super.onPresentScreen();
	    Toast.makeText(getApplicationContext(), "onPresentScreen rec", Toast.LENGTH_SHORT).show();
    }

	@Override
    public void onDismissScreen() {
	    // TODO Auto-generated method stub
	    super.onDismissScreen();
	    Toast.makeText(getApplicationContext(), "onDismissScreen rec", Toast.LENGTH_SHORT).show();
    }
}