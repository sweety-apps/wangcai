package com.punchbox.cocoaddemo;

import com.punchbox.ads.AdRequest;
import com.punchbox.ads.MoreGameAd;
import com.punchbox.exception.PBException;
import com.punchbox.listener.AdListener;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class MoreGameActivity extends Activity implements AdListener{

    MoreGameAd ad;
    String placementID = "替换成您的广告位ID";//没有可以为空
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);

      setContentView(R.layout.activity_moregame);
      
      //构建MoreGameAd实例
      ad = new MoreGameAd(this);
      //设置监听，本类继承了AdListener
      ad.setAdListener(this);
    }
    
    //xml布局文件中配置的按钮触发此函数
    public void moregame(View v){
      //加载广告,加载时机由开发者来决定
        ad.loadAd(new AdRequest());
      //调用展现。展现时机也可以由开发者在其他时候调用，确保一定在loadAd()调用之后，为了能让展现立即，开发者可以提前一点点时间调用loadAd()，这样能让展现不需要等待网络请求的过程。
        //如果精品推荐广告还未加载完毕，会出现加载进度条
        try {
            ad.showFloatView(this, 1.0, placementID);
        } catch (PBException e) {
            //当设置的scale不在范围内，或者isReady()属性为false
            e.printStackTrace();
        }
    }

    public void moregameActivity(View v){
        try{
            ad.showActivity(this, "test");
        } catch(PBException e){
            e.printStackTrace();
        }
    }
    
    @Override
    public void onDestroy(){
        super.onDestroy();
        ad.destroy();
    }
    
    //以下监听回调
    @Override
    public void onReceiveAd() {
      
    }

    @Override
    public void onFailedToReceiveAd(PBException ex) {
     // 在请求广告失败后回调
    }

    @Override
    public void onPresentScreen() {
     // 展示广告时回调 
    }

    @Override
    public void onDismissScreen() {
      //广告移除时回调
    }
}
