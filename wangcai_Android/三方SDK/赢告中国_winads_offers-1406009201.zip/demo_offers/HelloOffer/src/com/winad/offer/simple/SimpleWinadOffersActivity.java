package com.winad.offer.simple;




import com.winad.android.offers.AdManager;
import com.winad.android.offers.AdScoreListener;
import com.winad.android.offers.parameter.ShowEntranceListener;
import com.winad.android.offers.parameter.SpendScoreListener;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class SimpleWinadOffersActivity extends Activity implements
		OnClickListener, ShowEntranceListener, SpendScoreListener ,AdScoreListener{
	Button btn20, btn40, btn600, btnMyPoints;
	// 设置Point单位，默认为“积分”，可设置为“金币”等
	private String unit = "积分";
	private int scores;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// 初始化积分墙sdk
		AdManager.init(this);
		//设置积分墙显示单位
		AdManager.setPointUnit(this, unit);
		// 设置积分墙开关监听
		AdManager.setShowEntranceListener(this, this);
		
		//设置积分变化监听
		AdManager.setAdScoreListener(this);
		
		//设置自定义ID
		AdManager.setUserID(this,"userID");
		
		//隐藏或者显示积分墙显示页面显示积分“true为隐藏”，“false‘为显示
		AdManager.setButtonHide(this, true);
		btn20 = (Button) findViewById(R.id.btn20);
		btn20.setText("消费20" + unit);
		btn20.setOnClickListener(this);
		btn40 = (Button) findViewById(R.id.btn40);
		btn40.setText("消费40" + unit);
		btn40.setOnClickListener(this);
		btn600 = (Button) findViewById(R.id.btn600);
		btn600.setText("消费600" + unit);
		btn600.setOnClickListener(this);
		btnMyPoints = (Button) findViewById(R.id.btnMyPoints);
		btnMyPoints.setText("当前" + unit);
		btnMyPoints.setOnClickListener(this);
		btn20.setVisibility(View.GONE);
		btn40.setVisibility(View.GONE);
		btn600.setVisibility(View.GONE);
	}

	@Override
	public void EntranceHide() {
		// TODO Auto-generated method stub
		btn20.setVisibility(View.GONE);
		btn40.setVisibility(View.GONE);
		btn600.setVisibility(View.GONE);
	}

	@Override
	public void Entrancedisplay() {
		// TODO Auto-generated method stub

		btn20.setVisibility(View.VISIBLE);
		btn40.setVisibility(View.VISIBLE);
		btn600.setVisibility(View.VISIBLE);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int viewId = v.getId();
		switch (viewId) {
		case R.id.btn20:
			spendScore(20);
			break;
		case R.id.btn40:
			spendScore(40);
			break;
		case R.id.btn600:
			spendScore(600);
			break;
		case R.id.btnMyPoints:
			showMessageBox("当前" + unit,
					"当前账户" + unit + "余额为:" + AdManager.getPoints(this), false);
			break;
		default:
			break;
		}
	}

	public void spendScore(int score) {

		this.scores = score;
		/**
		 * this 上下文 this SpendScoreListener(消费积分监听) scores，需要消费的积分数
		 */
		AdManager.spendPoints(this, this, scores);
	}

	@Override
	public void ConsumptionLose(String errorCode) {
		// TODO Auto-generated method stub
		String msg = String.format("您的%s余额不足,当前账户%s余额为:%s", unit, unit,
				AdManager.getPoints(this) + "");
		showMessageBox(unit + "消费失败" + errorCode, msg, true);

	}

	@Override
	public void ConsumptionSuccess(int score) {
		// TODO Auto-generated method stub
		String msg = String.format("您已经成功消费%s%s,当前账户%s余额为:%s", score, unit,
				unit, AdManager.getPoints(this) + "");
		showMessageBox(unit + "消费成功", msg, false);

	}

	public void showMessageBox(String title, String msg, boolean isSetButton) {
		try {
			Builder builder = new android.app.AlertDialog.Builder(this);
			if (isSetButton) {
				builder.setTitle(title)
						.setMessage(msg)
						.setPositiveButton("获取" + unit,
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub
										AdManager
												.showAdOffers(SimpleWinadOffersActivity.this);
									}
								})
						.setNegativeButton("取消",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub

									}
								}).create().show();
			} else {
				builder.setTitle(title)
						.setMessage(msg)
						.setNegativeButton("确定",
								new DialogInterface.OnClickListener() {

									@Override
									public void onClick(DialogInterface dialog,
											int which) {
										// TODO Auto-generated method stub

									}
								}).create().show();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Override
	public void addScoreSucceed(int arg0) {
		// TODO Auto-generated method stub
		
	}

}