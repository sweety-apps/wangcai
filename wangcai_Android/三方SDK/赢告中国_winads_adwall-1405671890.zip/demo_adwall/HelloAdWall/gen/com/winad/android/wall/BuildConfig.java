/** Automatically generated file. DO NOT MODIFY */
package com.winad.android.wall;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}