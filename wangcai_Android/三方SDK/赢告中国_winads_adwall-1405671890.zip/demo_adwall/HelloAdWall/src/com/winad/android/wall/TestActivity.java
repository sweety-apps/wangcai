package com.winad.android.wall;

import com.winad.android.adwall.util.ShowAdwallEntranceListener;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class TestActivity extends Activity implements
		ShowAdwallEntranceListener {
	/** Called when the activity is first created. */
	ImageView image;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// WinadUtil.checkUpdate(this);//���°汾ʱ����
		image = (ImageView) findViewById(R.id.gifView);

		// ���ع��ǽ���
		image.setVisibility(View.GONE);
		
		//��濪�ش�ʱʵ�������ǽ
		AdWall.Instantiation(this);

		// ���ù��ǽ���ؼ���
		AdWall.setShowEntranceListener(this, this);

		image.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// �򿪹��ǽҳ��
				AdWall.starAdwall(TestActivity.this);
			}
		});

	}

	@Override
	public void AdWallEntranceHide() {
		// TODO Auto-generated method stub
		// ��濪�عر�ʱ���ع��ǽ���
		System.out.print("AdWallEntranceHide()...");
		image.setVisibility(View.GONE);

	}

	@Override
	public void AdWallEntrancedisplay() {
		// TODO Auto-generated method stub
		// ��濪�ش�ʱ��ʾ���ǽ���
		image.setVisibility(View.VISIBLE);
		System.out.print("AdWallEntrancedisplay...");

	}
}