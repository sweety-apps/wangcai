PhoneHomeTest
=============

Here's an example Android application that uses the PhoneHome API and interacts with the example backend provided in [example/backend](https://github.com/nebulabsnyc/PhoneHome/tree/master/example/backend). It enables/disables PhoneHome by checking device eligibility. It also provides an exmaple implementation of a log sink to send logs to the backend.
