Example
=======

Here's an example Android project that uses the PhoneHome library and a sample Flask (Python) backend that handles flushed logs.
