example/DomobOfferWallSample 文件夹为domob offerwall android sdk 测试样例 （注：必须先设置您的publisherId）
lib/domob_android_offer_wall_sdk.jar 为 domob offerwall android sdk 的开发包
doc 目录下是domob offerwall android sdk 的java doc
UserGuide.pdf 为domob offerwall android sdk 的安装手册帮您快速熟悉domob offerwall android sdk 的使用方法
如果打开javadoc出现乱码，请将浏览器的“字符编码”设置为“UTF-8”
