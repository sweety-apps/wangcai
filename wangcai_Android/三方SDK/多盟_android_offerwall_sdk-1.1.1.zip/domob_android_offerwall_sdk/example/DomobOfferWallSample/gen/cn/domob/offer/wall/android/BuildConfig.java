/** Automatically generated file. DO NOT MODIFY */
package cn.domob.offer.wall.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}