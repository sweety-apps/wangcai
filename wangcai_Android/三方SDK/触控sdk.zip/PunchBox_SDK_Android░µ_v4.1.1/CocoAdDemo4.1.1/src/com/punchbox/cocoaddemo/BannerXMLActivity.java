package com.punchbox.cocoaddemo;

import android.app.Activity;
import android.os.Bundle;

public class BannerXMLActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banner);
    }
}
