/********************************************code start*********************************************************/

var trackScript;
var channel = 20;
function track(cId, eventId, callback) {
    var cmsp=!(localStorage.getItem('cmsp'))?"":localStorage.getItem('cmsp');
    trackScript = null;
    trackScript = document.createElement("script");
    var src = "http://ama.adwo.com/tracknew/advTract/tractEventJsonP.action?cid=" + cId + "&eventid=" + eventId;
    if (callback != undefined && callback != null && callback != "") {
        src += '&callback=' + callback;
    }
    src += cmsp;
    src += '&_t=' + new Date().getTime();
    trackScript.type = "text/javascript";
    trackScript.src = src;
    document.getElementsByTagName("head")[0].appendChild(trackScript);
    
}

function eventcallback(result) {
    if(typeof trackScript==='undefined')
        return;
    document.getElementsByTagName("head")[0].removeChild(trackScript);
    trackScript=null;

}
function jsonp(url,callback){
    trackScript = null;
    trackScript = document.createElement("script");
    var src = url;
    if (callback != undefined && callback != null && callback != "") {
        src += '&callback=' + callback;
    }
    src += '&_t=' + new Date().getTime();
    trackScript.type = "text/javascript";
    trackScript.src = src;
    document.getElementsByTagName("head")[0].appendChild(trackScript);
}
/********************************************code end*********************************************************/
